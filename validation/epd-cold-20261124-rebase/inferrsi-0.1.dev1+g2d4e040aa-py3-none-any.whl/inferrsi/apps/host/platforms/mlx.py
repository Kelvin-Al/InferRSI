import platform


def _parse_sysctl_info(stdout: str) -> tuple[bool, str]:
    # Parse fixed sysctl text; static samples do not verify real hardware discovery.
    rows = [line.partition(":") for line in stdout.splitlines() if line.strip()]
    values = {name.strip(): value.strip() for name, _, value in rows}
    if len(rows) != 2 or set(values) != {"hw.optional.arm64", "machdep.cpu.brand_string"}:
        raise ValueError("sysctl must report ARM64 capability and chip identity")
    flag = values["hw.optional.arm64"]
    chip = values["machdep.cpu.brand_string"]
    if flag not in ("0", "1") or not chip:
        raise ValueError("sysctl reported an invalid ARM64 flag or empty chip identity")
    return flag == "1", chip


def _model_names(chip: str) -> set[str]:
    # A chip is selected by its whole name, with or without the "Apple" prefix,
    # so "M1" or "Pro" never selects an "Apple M1 Pro".
    name = " ".join(chip.casefold().split())
    return {name, name.removeprefix("apple ")}


def inspect_devices(*, device_ids, device_model, command):
    result = {"status": "unavailable", "tool": "sysctl", "selection_verified": False}
    if device_ids:
        result["reason"] = "MLX discovery does not support discrete device IDs (unified memory)"
        return result
    if platform.system() != "Darwin":
        result["reason"] = "MLX Apple Silicon discovery requires macOS"
        return result

    probe = command(["sysctl", "hw.optional.arm64", "machdep.cpu.brand_string"])
    result["probe"] = probe
    if probe["returncode"] != 0:
        result["reason"] = "sysctl could not report Apple Silicon hardware facts"
        return result
    try:
        arm64, chip = _parse_sysctl_info(probe["stdout"])
    except ValueError as exc:
        result["reason"] = str(exc)
        return result
    result["chip"] = chip
    if not arm64:
        result["reason"] = "Host is not Apple Silicon"
    elif device_model and " ".join(device_model.casefold().split()) not in _model_names(chip):
        result["status"] = "device_model_mismatch"
        result["reason"] = "Discovered chip does not match the requested device model"
    else:
        result["status"] = "available"
        result["selection_verified"] = True
    return result
