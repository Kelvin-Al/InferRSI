lily
Copyright 2026 Perplexity AI, Inc.

This product includes software developed as part of the lily project,
licensed under the Apache License, Version 2.0 (see LICENSE).

--------------------------------------------------------------------------------
Third-party attribution
--------------------------------------------------------------------------------

MLX
https://github.com/ml-explore/mlx

MLX-LM
https://github.com/ml-explore/mlx-lm

  lily reads MLX's affine 4-bit weight format ({codes, scales, biases}, group-
  wise). Portions of these Metal implementations were adapted from MLX and
  MLX-LM for lily's own dispatch and tile geometry:

    src/kernels/metal/attention.metal
      MLX sdpa_vector.h, sdpa_vector_2pass_1
      Copyright © 2024 Apple Inc.

    src/kernels/metal/quant.metal
      MLX quantized.h
      Copyright © 2023-2024 Apple Inc.

    src/kernels/metal/moe.metal
      MLX quantized.h and MLX-LM qwen3_next.py and switch_layers.py
      Copyright © 2023-2024 Apple Inc.
      Copyright © 2025 Apple Inc.

    src/kernels/metal/gdn.metal
      MLX-LM gated_delta.py

MLX and MLX-LM are licensed under the following terms:

MIT License

Copyright © 2023 Apple Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

--------------------------------------------------------------------------------

The Gated DeltaNet recurrence that tests/support/cpu_ref.rs and
src/kernels/gdn.rs implement, and the online-softmax formulation the
flash-attention prefill kernel uses, are published algorithms; the
implementations here are lily's.
